import React from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter as Router, Route } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
 
// import App from './App';
import AddDocument from './components/AddDocument';
import ListDocument from './components/ListDocument';
import EditDocument from './components/EditDocument';
import WriteBlog from './components/WriteBlog'
import Navbar from 'react-bootstrap/Navbar';
import Nav from 'react-bootstrap/Nav';
import NavDropdown from 'react-bootstrap/NavDropdown';
import About from './components/About';
import Services from './components/Services'
 
ReactDOM.render(
<Router>
<div>
<Navbar collapseOnSelect expand="lg" bg="dark" variant="dark">
  <Navbar.Brand href="#index">Home</Navbar.Brand>
  <Navbar.Toggle aria-controls="responsive-navbar-nav" />
  <Navbar.Collapse id="responsive-navbar-nav">
    <Nav className="mr-auto">
      <Nav.Link href="#About">About</Nav.Link>
      <Nav.Link href="#Services">Services</Nav.Link>
      <NavDropdown title="Blogs" id="collasible-nav-dropdown">
        <NavDropdown.Item href="#WriteBlog">Write Blogs</NavDropdown.Item>
        <NavDropdown.Item href="#action/3.2">Another action</NavDropdown.Item>
        <NavDropdown.Item href="#action/3.3">Something</NavDropdown.Item>
        <NavDropdown.Divider />
        <NavDropdown.Item href="#action/3.4">Separated link</NavDropdown.Item>
      </NavDropdown>
    </Nav>
    <Nav>
      <Nav.Link href="#deets">More deets</Nav.Link>
      <Nav.Link eventKey={2} href="#memes">
        Dank memes
      </Nav.Link>
    </Nav>
  </Navbar.Collapse>
</Navbar>
<Route exact path='/' component={ListDocument} />
<Route path='/add-document' component={AddDocument} />
<Route path='/index' component={ListDocument} />
<Route path='/edit-document/:id' component={EditDocument} />
<Route path='/WriteBlog' component={WriteBlog} />
<Route path='/About' component={About} />
<Route path='/Services' component={Services} />
</div>
</Router>,
document.getElementById('root')
);