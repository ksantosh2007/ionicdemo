import React, { Component } from 'react'

export class About extends Component {
    render() {
        return (
            <div>
                <p>About component</p>
            </div>
        )
    }
}

export default About
