import React, { Component } from 'react'

export class WriteBlog extends Component {
    render() {
        return (
            <div>
                <p>WriteBlog component</p>
                
            </div>
        )
    }
}

export default WriteBlog
