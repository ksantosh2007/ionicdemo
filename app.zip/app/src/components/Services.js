import React, { Component } from 'react'

export class Services extends Component {
    render() {
        return (
            <div>
                <p>Services</p>
            </div>
        )
    }
}

export default Services

